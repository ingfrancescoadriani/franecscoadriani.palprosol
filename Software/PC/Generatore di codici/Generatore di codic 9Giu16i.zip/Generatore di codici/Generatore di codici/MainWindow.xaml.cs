﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Sintec.Tool;

namespace Generatore_di_codici
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //String key = AppSettingsManager.Istance.getAppSettings("Key");
            //String hwCode = key.Split('-')[0];
            //String dateCode = key.Split('-')[1];
            //String date = HwProtection.Decrypt(dateCode);
            ////String checkSumADteCode = key.Split('-')[2];
            //bool dateOk = (DateTime.Now < DateTime.Parse(date)) && (HwProtection.getMD5(date) == checkSumADteCode);
            //if ((!HwProtection.verifyHdMD5(hwCode)) || !dateOk)
            //{
            //    String pippo = Microsoft.VisualBasic.Interaction.InputBox("Plc-connection library code invalid!", "Insert a valid code", HwProtection.diskCodeMD5());
            //    if (pippo == "")
            //    {
            //        throw (new Exception("Plc-connection library code invalid!"));
            //    }
            //    else
            //    {
            //    }
            //}
            textBox5.Text = HwProtection.diskCodeMD5();
            textBox1.Text = HwProtection.dllCode(textBox5.Text).ToString();
            datePicker1.SelectedDate = DateTime.Now;
        }

        private void datePicker1_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            textBox2.Text = HwProtection.Encrypt(datePicker1.SelectedDate.Value.ToString("dd/MM/yyyy")).ToString();
            textBox3.Text = HwProtection.getMD5(datePicker1.SelectedDate.Value.ToString("dd/MM/yyyy"));
            //String date = HwProtection.Encrypt(dateCode);
            ////String checkSumADteCode = key.Split('-')[2];
            //bool dateOk = (DateTime.Now < DateTime.Parse(date)) && (HwProtection.getMD5(date) == checkSumADteCode);
            //if ((!HwProtection.verifyHdMD5(hwCode)) || !dateOk)
            //{
            //    String pippo = Microsoft.VisualBasic.Interaction.InputBox("Plc-connection library code invalid!", "Insert a valid code", HwProtection.diskCodeMD5());
            //    if (pippo == "")
            //    {
            //        throw (new Exception("Plc-connection library code invalid!"));
            //    }
            //    else
            //    {
            //    }
            //}
            button1_Click(null, null);
            //textBox4.Text = textBox1.Text + "-" + HwProtection.Encrypt(datePicker1.DisplayDate.ToShortDateString()).ToString() + "-" + HwProtection.getMD5(datePicker1.DisplayDate.ToShortDateString()).ToString();
        }

        private void textBox5_TextChanged(object sender, TextChangedEventArgs e)
        {
            textBox1.Text = HwProtection.dllCode(textBox5.Text).ToString();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            textBox4.Text = textBox1.Text + "-" + HwProtection.Encrypt(datePicker1.SelectedDate.Value.ToShortDateString()).ToString() + "-" + HwProtection.getMD5(datePicker1.SelectedDate.Value.ToShortDateString()).ToString();
        }

        private void textBox4_GotFocus(object sender, RoutedEventArgs e)
        {
            textBox4.SelectAll();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            new WindowCheckCode(textBox4.Text).Show();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            GetMacAddressFromIPAddress g = new GetMacAddressFromIPAddress();
            String res = g.GetMACAddressFromARP(textBox6.Text);
            if (String.IsNullOrEmpty(res))
                MessageBox.Show("Ip non connesso al pc");
            else
                textBox5.Text = res.ToUpper();
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            textBox5.Text = HwProtection.diskCodeMD5();
        }
    }
}
