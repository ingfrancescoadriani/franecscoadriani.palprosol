﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Sintec.Tool;
using System.Globalization;

namespace Generatore_di_codici
{
    /// <summary>
    /// Interaction logic for WindowCheckCode.xaml
    /// </summary>
    public partial class WindowCheckCode : Window
    {
        String code;
        public WindowCheckCode(String code)
        {
            InitializeComponent();
            this.code = code;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            String key = textBox4.Text;
            String hwCode = key.Split('-')[0];
            String dateCode = key.Split('-')[1];
            String date = HwProtection.Decrypt(dateCode);
            datePicker1.DisplayDate = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            datePicker1.SelectedDate = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            String checkSumADteCode = key.Split('-')[2];
            lblCheckSum.Content = (HwProtection.getMD5(date) == checkSumADteCode) ? "OK" : "NOK";
            if (radioButton1.IsChecked.Value)
                lblVerifica.Content = HwProtection.verifyHdMD5(hwCode) ? "OK" : "NOK";
            else
                lblVerifica.Content = HwProtection.verifyCustomCodeMD5(hwCode, textBox2.Text.ToUpper()) ? "OK" : "NOK";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            textBox4.Text = code;
        }
    }
}
